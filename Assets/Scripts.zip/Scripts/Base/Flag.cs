using UnityEngine;

public class Flag : MonoBehaviour
{
}
